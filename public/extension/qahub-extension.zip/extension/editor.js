// editor.js

// --- CONFIGURAÇÕES ---
const API_BASE_URL = 'https://qa.projetoslayerup.com.br/api'; // URL atualizada
let canvas;
let currentTool = 'select';
let projectId = null;
let authToken = null;
let currentColor = '#ef4444'; // Cor padrão (Vermelho)
let capturedUrl = ''; // Nova variável para armazenar a URL da página

function initCanvas() {
    canvas = new fabric.Canvas('c', {
        selection: false, // Começa false, ativamos no modo select
        preserveObjectStacking: true,
        backgroundColor: '#fff'
    });

    // --- CARREGAMENTO INICIAL (Token, Print, Projeto, PageUrl) ---
    chrome.storage.sync.get(['token'], (syncResult) => {
        authToken = syncResult.token;
        
        // Adicionado 'pageUrl' na busca do storage local
        chrome.storage.local.get(['screenshot', 'selectedProjectId', 'pageUrl'], (localResult) => {
            projectId = localResult.selectedProjectId;
            capturedUrl = localResult.pageUrl || ''; // Recupera a URL
            
            console.log('URL da Página:', capturedUrl); // Debug

            if (authToken && projectId) {
                document.getElementById('project-name-display').textContent = 'Projeto Carregado';
                loadTeams(projectId);
            } else {
                // Se faltar token ou projeto, avisa (opcional)
                console.warn('Token ou Projeto não identificados.');
            }

            if (localResult.screenshot) {
                fabric.Image.fromURL(localResult.screenshot, (img) => {
                    const pixelRatio = window.devicePixelRatio || 1;
                    const scaleFactor = 1 / pixelRatio;
                    
                    canvas.setWidth(img.width * scaleFactor);
                    canvas.setHeight(img.height * scaleFactor);
                    
                    img.set({ 
                        left: 0, top: 0, 
                        selectable: false, 
                        evented: false, // Importante: impede que a borracha interaja com o fundo
                        scaleX: scaleFactor, scaleY: scaleFactor 
                    });
                    
                    canvas.add(img);
                    canvas.sendToBack(img);
                });
            }
        });
    });

    setupTools();
    setupColorPicker();
    setupFormListeners();
    setupKeyboardEvents();
}

// --- CONTROLE DE COR ---
function setupColorPicker() {
    const picker = document.getElementById('color-picker');
    
    if (!picker) return;

    // 1. Quando mudar a cor no input
    picker.addEventListener('input', (e) => {
        currentColor = e.target.value;
        
        // Se tiver algo selecionado, muda a cor dele imediatamente
        const activeObj = canvas.getActiveObject();
        if (activeObj) {
            // Trata diferentes tipos de objetos
            if (activeObj.type === 'path' || activeObj.type === 'line') {
                activeObj.set({ stroke: currentColor });
            } else if (activeObj.type === 'i-text') {
                activeObj.set({ fill: currentColor });
            } else {
                // Retangulos e Circulos (Stroked)
                activeObj.set({ stroke: currentColor });
            }
            canvas.renderAll();
        }
        
        // Se estiver no modo Caneta, atualiza o pincel
        if (canvas.freeDrawingBrush) {
            canvas.freeDrawingBrush.color = currentColor;
        }
    });

    // 2. Quando selecionar um objeto no canvas, atualiza o picker para a cor dele
    canvas.on('selection:created', updatePickerFromSelection);
    canvas.on('selection:updated', updatePickerFromSelection);
}

function updatePickerFromSelection(e) {
    const obj = e.selected[0];
    if (!obj) return;
    
    let colorToSet = currentColor;
    // Tenta descobrir a cor do objeto (stroke ou fill)
    if (obj.stroke && obj.stroke !== 'transparent') colorToSet = obj.stroke;
    if (obj.fill && obj.fill !== 'transparent' && obj.type === 'i-text') colorToSet = obj.fill;
    
    const picker = document.getElementById('color-picker');
    if (picker) picker.value = colorToSet;
    currentColor = colorToSet;
    
    // Atualiza pincel se necessário
    if (canvas.freeDrawingBrush) canvas.freeDrawingBrush.color = currentColor;
}


// --- FERRAMENTAS ---
function setupTools() {
    document.querySelectorAll('.toolbar button[data-tool]').forEach((btn) => {
        btn.addEventListener('click', () => {
            activateTool(btn.getAttribute('data-tool'));
        });
    });

    document.getElementById('undo-btn').addEventListener('click', () => {
        const objects = canvas.getObjects();
        // Remove o último, mas ignora a imagem de fundo (índice 0)
        // Verificamos se objects.length > 1 pois o index 0 é o print
        if (objects.length > 1) { 
            canvas.remove(objects[objects.length - 1]);
        }
    });

    // Botão extra de Limpar (opcional)
    const clearBtn = document.getElementById('clear-btn');
    if(clearBtn) {
        clearBtn.addEventListener('click', () => {
            const objects = canvas.getObjects();
            // Remove tudo do índice 1 pra frente (preserva fundo)
            for (let i = objects.length - 1; i > 0; i--) {
                canvas.remove(objects[i]);
            }
        });
    }
}

function activateTool(tool) {
    // UI Update
    document.querySelectorAll('.toolbar button').forEach(b => b.classList.remove('active'));
    const btn = document.querySelector(`.toolbar button[data-tool="${tool}"]`);
    if(btn) btn.classList.add('active');

    currentTool = tool;
    
    // Reset Canvas State
    canvas.isDrawingMode = false;
    canvas.selection = false;
    canvas.defaultCursor = 'default';
    canvas.discardActiveObject();
    canvas.renderAll();
    
    // Limpa eventos antigos de desenho
    canvas.off('mouse:down');
    canvas.off('mouse:move');
    canvas.off('mouse:up');

    // Configura nova ferramenta
    if (tool === 'select') {
        canvas.selection = true; 
        canvas.forEachObject(o => { if(o.type !== 'image') o.selectable = true; });

    } else if (tool === 'pen') {
        canvas.isDrawingMode = true;
        canvas.freeDrawingBrush = new fabric.PencilBrush(canvas);
        canvas.freeDrawingBrush.width = 4;
        canvas.freeDrawingBrush.color = currentColor;
        canvas.forEachObject(o => o.selectable = false);

    } else if (tool === 'eraser') {
        canvas.defaultCursor = 'not-allowed'; 
        canvas.forEachObject(o => o.selectable = false);
        
        // Lógica de Apagar ao Clicar
        canvas.on('mouse:down', (opt) => {
            if (opt.target && opt.target.type !== 'image') {
                canvas.remove(opt.target);
                canvas.renderAll();
            }
        });

    } else {
        // Formas e Texto
        canvas.defaultCursor = 'crosshair';
        canvas.forEachObject(o => o.selectable = false);
        setupObjectCreation(tool);
    }
}

function setupObjectCreation(tool) {
    let isDrawing = false;
    let origX, origY;
    let activeObj;

    canvas.on('mouse:down', (o) => {
        // Se clicou em algo existente e não é texto, não cria nada novo
        if (o.target && tool !== 'text') return;

        isDrawing = true;
        const pointer = canvas.getPointer(o.e);
        origX = pointer.x;
        origY = pointer.y;

        const commonProps = {
            left: origX, top: origY, originX: 'left', originY: 'top',
            stroke: currentColor, strokeWidth: 3, fill: 'transparent',
            selectable: true
        };

        if (tool === 'rect') {
            activeObj = new fabric.Rect({ ...commonProps, width: 0, height: 0 });
        } else if (tool === 'circle') {
            activeObj = new fabric.Ellipse({ ...commonProps, rx: 0, ry: 0 });
        } else if (tool === 'arrow') {
            activeObj = new fabric.Line([origX, origY, origX, origY], {
                stroke: currentColor, strokeWidth: 3, selectable: true
            });
        } else if (tool === 'text') {
            const text = new fabric.IText('Texto', {
                left: origX, top: origY, 
                fill: currentColor, fontSize: 24,
                selectable: true
            });
            canvas.add(text);
            canvas.setActiveObject(text);
            text.enterEditing();
            text.selectAll();
            
            // Auto-switch para Select após criar texto
            isDrawing = false;
            activateTool('select'); 
            return;
        }

        if (activeObj) canvas.add(activeObj);
    });

    canvas.on('mouse:move', (o) => {
        if (!isDrawing || !activeObj) return;
        const pointer = canvas.getPointer(o.e);

        if (tool === 'rect') {
            if(origX > pointer.x) activeObj.set({ left: Math.abs(pointer.x) });
            if(origY > pointer.y) activeObj.set({ top: Math.abs(pointer.y) });
            activeObj.set({ width: Math.abs(origX - pointer.x), height: Math.abs(origY - pointer.y) });
        } else if (tool === 'circle') {
            if(origX > pointer.x) activeObj.set({ left: Math.abs(pointer.x) });
            if(origY > pointer.y) activeObj.set({ top: Math.abs(pointer.y) });
            activeObj.set({ rx: Math.abs(origX - pointer.x) / 2, ry: Math.abs(origY - pointer.y) / 2 });
        } else if (tool === 'arrow') {
            activeObj.set({ x2: pointer.x, y2: pointer.y });
        }
        canvas.renderAll();
    });

    canvas.on('mouse:up', () => {
        if(isDrawing && activeObj) {
            activeObj.setCoords(); 
        }
        isDrawing = false;
        activeObj = null;
    });
}

function setupKeyboardEvents() {
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Delete' || e.key === 'Backspace') {
            const activeElement = document.activeElement;
            const isInput = activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA';
            
            const activeObj = canvas.getActiveObject();
            const isEditingText = activeObj && activeObj.isEditing;

            if (!isInput && !isEditingText && activeObj) {
                 canvas.remove(activeObj);
            }
        }
    });
}

// --- API LOADERS ---

function loadTeams(projId) {
    const teamSelect = document.getElementById('task-team');
    teamSelect.innerHTML = '<option disabled selected>Carregando times...</option>';
    
    fetch(`${API_BASE_URL}/projects/${projId}/teams`, {
        headers: { 
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json'
        }
    })
    .then(res => res.json())
    .then(data => {
        teamSelect.innerHTML = '<option value="" disabled selected>Selecionar Time</option>';
        const teams = data.teams || [];
        
        if(teams.length === 0) {
             const opt = document.createElement('option');
             opt.disabled = true; 
             opt.textContent = "Nenhum time";
             teamSelect.appendChild(opt);
             return;
        }

        teams.forEach(team => {
            const opt = document.createElement('option');
            opt.value = team.id; 
            opt.textContent = team.name; 
            teamSelect.appendChild(opt);
        });
    })
    .catch(err => {
        console.error('Erro ao carregar times', err);
        teamSelect.innerHTML = '<option disabled>Erro ao carregar</option>';
    });
}

function loadCategories(projId, teamId) {
    const catSelect = document.getElementById('task-category');
    catSelect.disabled = false;
    catSelect.innerHTML = '<option disabled selected>Carregando...</option>';
    
    fetch(`${API_BASE_URL}/projects/${projId}/teams/${teamId}/categories`, {
        headers: { 
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json'
        }
    })
    .then(res => res.json())
    .then(data => {
        catSelect.innerHTML = '<option value="" disabled selected>Selecionar Categoria</option>';
        const categories = data.categories || [];
        
        if(categories.length === 0) {
             const opt = document.createElement('option');
             opt.disabled = true; 
             opt.textContent = "Nenhuma categoria";
             catSelect.appendChild(opt);
             return;
        }

        categories.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat.id; 
            opt.textContent = cat.title; 
            catSelect.appendChild(opt);
        });
    })
    .catch(err => {
        console.error('Erro ao carregar categorias', err);
        catSelect.innerHTML = '<option disabled>Erro ao carregar</option>';
    });
}

function setupFormListeners() {
    const teamSelect = document.getElementById('task-team');
    teamSelect.addEventListener('change', (e) => {
        if (e.target.value && projectId) {
            loadCategories(projectId, e.target.value);
        }
    });
    document.getElementById('save-send-btn').addEventListener('click', handleSaveTask);
}

// --- ENVIO DA TAREFA ---

function handleSaveTask() {
    const btn = document.getElementById('save-send-btn');
    const status = document.getElementById('status-msg');

    const title = document.getElementById('task-title').value;
    const description = document.getElementById('task-desc').value;
    const teamId = document.getElementById('task-team').value;
    const categoryId = document.getElementById('task-category').value;
    
    const priorityEl = document.querySelector('input[name="priority"]:checked');
    // Fallback para 'media' (valor em português para o banco)
    const priority = priorityEl ? priorityEl.value : 'media'; 

    // Validações
    if (!title) { alert('Digite um título para a tarefa.'); return; }
    if (!teamId) { alert('Selecione um time.'); return; }
    if (!categoryId) { alert('Selecione uma categoria.'); return; }
    if (!projectId) { alert('ID do Projeto perdido. Recarregue a extensão.'); return; }

    // Loading
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Enviando...';
    status.classList.remove('hidden');
    status.textContent = 'Processando imagem...';
    status.style.color = 'var(--muted)';

    // Prepara a imagem (Blob)
    const dataUrl = canvas.toDataURL({ format: 'png', multiplier: 2 });
    const imageBlob = dataURItoBlob(dataUrl);

    // Prepara o FormData
    const formData = new FormData();
    formData.append('title', title);
    formData.append('description', description || '');
    formData.append('priority', priority);
    
    // Atenção: O team_id e category_id são enviados como string
    formData.append('category_id', categoryId);
    
    // Se o seu banco ainda der erro de coluna 'team_id' inexistente, comente a linha abaixo
    // Se você já corrigiu o banco ou se a API ignora campos extras, pode manter
    formData.append('team_id', teamId); 

    // NÃO enviamos project_id no corpo, pois ele vai na URL
    
    // Envia a URL da página (se existir)
    if (capturedUrl) {
        formData.append('page_url', capturedUrl);
    }
    
    // Anexa arquivo de imagem
    formData.append('image', imageBlob, 'screenshot.png');

    const targetUrl = `${API_BASE_URL}/projects/${projectId}/tasks`;
    console.log(`Enviando para: ${targetUrl}`);

    fetch(targetUrl, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${authToken}`
            // Não defina Content-Type aqui, o navegador define multipart/form-data automático
        },
        body: formData
    })
    .then(async (res) => {
        if (!res.ok) {
            const raw = await res.text();
            let errorMsg = raw;
            try {
                const json = JSON.parse(raw);
                errorMsg = json.message || json.error || raw;
            } catch(e) {}
            throw new Error(errorMsg);
        }
        return res.json();
    })
    .then((data) => {
        console.log('Sucesso:', data);
        btn.innerHTML = '<i class="fa-solid fa-check"></i> Sucesso!';
        btn.style.backgroundColor = '#10b981'; // Green variable
        status.textContent = 'Tarefa enviada com sucesso!';
        status.style.color = '#10b981';

        setTimeout(() => {
            window.close();
        }, 2000);
    })
    .catch((err) => {
        console.error('Erro no envio:', err);
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Tentar Novamente';
        
        // Mostra erro amigável se possível
        status.textContent = `Erro: ${err.message.substring(0,60)}...`;
        status.style.color = '#ef4444'; // Red variable
        alert(`Detalhe do erro:\n${err.message}`);
    });
}

// Helper: Converte DataURI para Blob
function dataURItoBlob(dataURI) {
    const byteString = atob(dataURI.split(',')[1]);
    const mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ab], { type: mimeString });
}

document.addEventListener('DOMContentLoaded', initCanvas);