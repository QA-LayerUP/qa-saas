// CONFIGURAÇÕES
const API_LOGIN_URL = 'https://qa.projetoslayerup.com.br/api/auth/login'; // Troque pela URL real
const API_PROJECTS_URL = 'https://qa.projetoslayerup.com.br/api/projects'; 

document.addEventListener('DOMContentLoaded', () => {
    // 1. Ao abrir, verifica se já está logado
    checkLoginStatus();

    // Listeners dos botões
    document.getElementById('login-btn').addEventListener('click', handleLogin);
    document.getElementById('logout-btn').addEventListener('click', handleLogout);
    document.getElementById('capture-btn').addEventListener('click', handleCapture);
});

// --- GERENCIAMENTO DE ESTADO (LOGIN/LOGOUT) ---

function checkLoginStatus() {
    // Busca token e dados do usuário salvos no navegador
    chrome.storage.sync.get(['token', 'user'], (result) => {
        if (result.token && result.user) {
            // Se tem token, MOSTRA o painel principal
            showMainSection(result.user);
        } else {
            // Se não, MOSTRA a tela de login
            showLoginSection();
        }
    });
}

function showLoginSection() {
    // Exibe Login, Oculta Principal e Footer
    document.getElementById('login-section').classList.remove('hidden');
    document.getElementById('main-section').classList.add('hidden');
    document.getElementById('app-footer').classList.add('hidden');
}

function showMainSection(user) {
    // Oculta Login, Exibe Principal e Footer
    document.getElementById('login-section').classList.add('hidden');
    document.getElementById('main-section').classList.remove('hidden');
    document.getElementById('app-footer').classList.remove('hidden');
    
    // Preenche o nome do usuário no rodapé
    // Tenta pegar o nome do metadado (user_metadata.name), senão usa o email
    const displayName = user.user_metadata?.name || user.email || 'Usuário';
    document.getElementById('user-display').textContent = displayName;

    // Carrega a lista de projetos da API
    fetchProjects();
}

function handleLogout() {
    // 1. Limpa o storage do Chrome
    chrome.storage.sync.clear(() => {
        // 2. Volta para a tela de login
        showLoginSection();
        
        // 3. Limpa o select de projetos para não ficar com dados velhos
        document.getElementById('project-select').innerHTML = '<option value="" disabled selected>Carregando...</option>';
    });
}

// --- FUNÇÕES DE API (Login e Projetos) ---

function handleLogin() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const errorEl = document.getElementById('login-error');
    const loginBtn = document.getElementById('login-btn');

    // Validação simples
    if (!email || !password) {
        errorEl.textContent = 'Preencha todos os campos.';
        errorEl.classList.remove('hidden');
        return;
    }

    // Feedback visual (Loading)
    errorEl.classList.add('hidden');
    loginBtn.textContent = 'Entrando...';
    loginBtn.disabled = true;

    // Chamada para API de Login
    fetch(API_LOGIN_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    })
    .then(async (res) => {
        const data = await res.json();
        if (!res.ok) throw new Error(data.error_description || 'Credenciais inválidas');
        return data;
    })
    .then((data) => {
        // O login retorna { session: { access_token... }, user: { ... } }
        const token = data.session?.access_token;
        const user = data.user;

        if (!token) throw new Error('Erro: Token não recebido.');

        // Salva token e usuário no Storage
        chrome.storage.sync.set({ token, user }, () => {
            // Avança para a tela principal
            showMainSection(user);
        });
    })
    .catch((err) => {
        errorEl.textContent = err.message;
        errorEl.classList.remove('hidden');
    })
    .finally(() => {
        loginBtn.textContent = 'Entrar';
        loginBtn.disabled = false;
    });
}

function fetchProjects() {
    chrome.storage.sync.get(['token'], (result) => {
        const token = result.token;
        const select = document.getElementById('project-select');
        
        if (!token) return;

        // Cabeçalhos com o Token Bearer
        const headers = { 
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        };

        // Chamada real para a API de Projetos
        fetch(API_PROJECTS_URL, { headers })
            .then(res => {
                if (!res.ok) throw new Error('Falha ao buscar projetos');
                return res.json();
            })
            .then(data => {
                // Limpa o select
                select.innerHTML = '<option value="" disabled selected>Selecione um projeto...</option>';
                
                // O JSON retornado tem a estrutura: { user: {...}, projects: [...] }
                // Então acessamos data.projects
                const projects = data.projects || [];

                if (projects.length === 0) {
                    const opt = document.createElement('option');
                    opt.disabled = true;
                    opt.textContent = "Nenhum projeto encontrado";
                    select.appendChild(opt);
                    return;
                }

                // Popula o select
                projects.forEach(proj => {
                    const opt = document.createElement('option');
                    opt.value = proj.id; // ID para envio
                    // Exibe "Nome (Cliente)" para facilitar identificação
                    opt.textContent = `${proj.name} (${proj.client})`; 
                    select.appendChild(opt);
                });
            })
            .catch(err => {
                console.error('Erro ao buscar projetos', err);
                select.innerHTML = '<option disabled>Erro ao carregar projetos</option>';
            });
    });
}

// --- CAPTURA DE TELA ---

function handleCapture() {
    const projectId = document.getElementById('project-select').value;
    const statusEl = document.getElementById('capture-status');

    if (!projectId) {
        statusEl.textContent = 'Por favor, selecione um projeto.';
        statusEl.classList.remove('hidden');
        statusEl.style.color = 'var(--danger)';
        return;
    }

    // 1. Salva o ID do projeto selecionado no storage LOCAL (para o editor usar depois)
    chrome.storage.local.set({ selectedProjectId: projectId }, () => {
        
        // 2. Feedback visual
        statusEl.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Preparando captura...';
        statusEl.classList.remove('hidden');
        statusEl.style.color = 'var(--muted)';

        // 3. Envia mensagem para o background.js tirar o print
        chrome.runtime.sendMessage({ action: 'capture' }, (response) => {
            if (response && response.success) {
                // Se deu certo, fecha o popup (o background abre o editor)
                window.close();
            } else {
                statusEl.textContent = 'Erro ao capturar tela.';
                statusEl.style.color = 'var(--danger)';
            }
        });
    });
}