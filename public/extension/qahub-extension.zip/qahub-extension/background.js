// background.js - Service Worker atualizado

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'capture') {
    console.log('1. Recebi pedido de captura.');

    // 1. Pega a aba ativa para descobrir a URL atual
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const activeTab = tabs[0];
      const currentUrl = activeTab ? activeTab.url : '';

      console.log('2. URL identificada:', currentUrl);

      // 2. Tenta capturar a aba visível (Print)
      chrome.tabs.captureVisibleTab(null, { format: 'png' }, (dataUrl) => {
        // Verifica erros imediatos do Chrome
        if (chrome.runtime.lastError) {
          console.error('ERRO NA CAPTURA:', chrome.runtime.lastError.message);
          sendResponse({ success: false, error: chrome.runtime.lastError.message });
          return;
        }

        if (!dataUrl) {
          console.error('ERRO: DataURL veio vazio.');
          sendResponse({ success: false, error: 'Imagem vazia gerada.' });
          return;
        }

        console.log('3. Captura realizada com sucesso. Comprimento da string:', dataUrl.length);

        // 3. Salva no storage: O Print E a URL da página
        chrome.storage.local.set({ 
            screenshot: dataUrl,
            pageUrl: currentUrl // <--- Salvando a URL aqui
        }, () => {
          
          if (chrome.runtime.lastError) {
            console.error('ERRO AO SALVAR NO STORAGE:', chrome.runtime.lastError);
            return;
          }
          
          console.log('4. Dados salvos no storage. Abrindo editor...');

          // 4. Abre a janela do editor (Maximizada para melhor UX)
          chrome.windows.create({
            url: 'editor.html',
            type: 'popup',
            width: 1400,
            height: 800
          }, (win) => {
            console.log('4. Janela do editor aberta (ID):', win.id);
            sendResponse({ success: true, windowId: win.id });
          });
        });
      });
    });

    // Retorna true para manter o canal de mensagem aberto (necessário para async)
    return true;
  }
});